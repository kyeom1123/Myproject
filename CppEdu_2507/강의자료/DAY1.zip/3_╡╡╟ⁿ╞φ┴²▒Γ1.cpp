﻿#include <iostream>
#include <vector>

// 파워 포인트 같은 프로그램을 객체지향으로 설계해 봅시다.

int main()
{

}

