#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/temperature.hpp>
#include "temperature_sensor.hpp"

using namespace std::chrono_literals;

class SensorPublisher : public rclcpp::Node
{
public:
  SensorPublisher()
  : Node("sensor_publisher"), sensor_(std::make_shared<TemperatureSensor>())
  {
    publisher_ = this->create_publisher<sensor_msgs::msg::Temperature>("temperature", 10);
    timer_ = this->create_wall_timer(1s, std::bind(&SensorPublisher::publish_temperature, this));
  }

private:
  void publish_temperature()
  {
    auto msg = sensor_msgs::msg::Temperature();
    msg.temperature = sensor_->read_temperature();
    msg.header.stamp = this->now();
    msg.header.frame_id = "sensor_frame";
    RCLCPP_INFO(this->get_logger(), "Publishing: %.2f °C", msg.temperature);
    publisher_->publish(msg);
  }

  rclcpp::Publisher<sensor_msgs::msg::Temperature>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
  std::shared_ptr<SensorBase> sensor_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SensorPublisher>());
  rclcpp::shutdown();
  return 0;
}
